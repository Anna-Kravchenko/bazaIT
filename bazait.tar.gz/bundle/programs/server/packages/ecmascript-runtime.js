(function () {



/* Exports */
Package._define("ecmascript-runtime");

})();
