var require = meteorInstall({"server":{"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////
//                                                                       //
// server/main.js                                                        //
//                                                                       //
///////////////////////////////////////////////////////////////////////////
                                                                         //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
//import winston from 'winston';
//var winston  = require('winston');
//require('winston-loggly-bulk');
// winston.add(winston.transports.Loggly, {
//   inputToken: "TOKEN",
//   subdomain: "SUBDOMAIN",
//   tags: ["meteor", "winston"],
//   json:true
// });
Meteor.startup(() => {// code to run on server at startup
});

if (Meteor.isServer) {
  console.log("Hello server"); //\.meteor\local\build\programs\server

  Meteor.methods({
    'logToFile': function (message) {
      var log4js = require('log4js');

      log4js.configure({
        appenders: {
          cheese: {
            type: 'file',
            filename: 'cheese.log'
          }
        },
        categories: {
          default: {
            appenders: ['cheese'],
            level: 'error'
          }
        }
      });
      var logger = log4js.getLogger('cheese');
      logger.level = 'debug'; //var infa;// = Session.get('loggerInfo');

      logger.debug(message); // var log4js = require('log4js');
      // var logger = log4js.getLogger();
      // logger.level = 'debug';
      // logger.debug(message);
    }
  }); //logger.debug("Some debug messages");
  //log.info("logString");

  Accounts.onCreateUser(function (options, user) {
    //pass the surname in the options
    console.log(options.profile); //log.info('User updated with ', options.profile, ' accepted at ', new Date().toJSON());

    user.profile = options.profile;
    return user;
  });
}
///////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwibGluayIsInYiLCJzdGFydHVwIiwiaXNTZXJ2ZXIiLCJjb25zb2xlIiwibG9nIiwibWV0aG9kcyIsIm1lc3NhZ2UiLCJsb2c0anMiLCJyZXF1aXJlIiwiY29uZmlndXJlIiwiYXBwZW5kZXJzIiwiY2hlZXNlIiwidHlwZSIsImZpbGVuYW1lIiwiY2F0ZWdvcmllcyIsImRlZmF1bHQiLCJsZXZlbCIsImxvZ2dlciIsImdldExvZ2dlciIsImRlYnVnIiwiQWNjb3VudHMiLCJvbkNyZWF0ZVVzZXIiLCJvcHRpb25zIiwidXNlciIsInByb2ZpbGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBSjtBQUFXQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNGLFFBQU0sQ0FBQ0csQ0FBRCxFQUFHO0FBQUNILFVBQU0sR0FBQ0csQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUNYO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUtBSCxNQUFNLENBQUNJLE9BQVAsQ0FBZSxNQUFNLENBQ25CO0FBQ0QsQ0FGRDs7QUFJQSxJQUFHSixNQUFNLENBQUNLLFFBQVYsRUFBbUI7QUFDZkMsU0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWixFQURlLENBSWxCOztBQUVBUCxRQUFNLENBQUNRLE9BQVAsQ0FBZTtBQUVkLGlCQUFhLFVBQVNDLE9BQVQsRUFBaUI7QUFFMUIsVUFBSUMsTUFBTSxHQUFHQyxPQUFPLENBQUMsUUFBRCxDQUFwQjs7QUFDSEQsWUFBTSxDQUFDRSxTQUFQLENBQWlCO0FBQ2ZDLGlCQUFTLEVBQUU7QUFBRUMsZ0JBQU0sRUFBRTtBQUFFQyxnQkFBSSxFQUFFLE1BQVI7QUFBZ0JDLG9CQUFRLEVBQUU7QUFBMUI7QUFBVixTQURJO0FBRWZDLGtCQUFVLEVBQUU7QUFBRUMsaUJBQU8sRUFBRTtBQUFFTCxxQkFBUyxFQUFFLENBQUMsUUFBRCxDQUFiO0FBQXlCTSxpQkFBSyxFQUFFO0FBQWhDO0FBQVg7QUFGRyxPQUFqQjtBQUtBLFVBQUlDLE1BQU0sR0FBR1YsTUFBTSxDQUFDVyxTQUFQLENBQWlCLFFBQWpCLENBQWI7QUFFQUQsWUFBTSxDQUFDRCxLQUFQLEdBQWUsT0FBZixDQVY2QixDQVk3Qjs7QUFFQUMsWUFBTSxDQUFDRSxLQUFQLENBQWFiLE9BQWIsRUFkNkIsQ0FnQjdCO0FBQ0E7QUFDQTtBQUNBO0FBQ0c7QUF0QlUsR0FBZixFQU5rQixDQW1DbEI7QUFDRzs7QUFDQWMsVUFBUSxDQUFDQyxZQUFULENBQXNCLFVBQVNDLE9BQVQsRUFBa0JDLElBQWxCLEVBQXdCO0FBQzlDO0FBQ0lwQixXQUFPLENBQUNDLEdBQVIsQ0FBWWtCLE9BQU8sQ0FBQ0UsT0FBcEIsRUFGMEMsQ0FHMUM7O0FBQ0FELFFBQUksQ0FBQ0MsT0FBTCxHQUFlRixPQUFPLENBQUNFLE9BQXZCO0FBQ0EsV0FBT0QsSUFBUDtBQUNILEdBTkQ7QUFPSCxDIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbi8vaW1wb3J0IHdpbnN0b24gZnJvbSAnd2luc3Rvbic7XG5cbi8vdmFyIHdpbnN0b24gID0gcmVxdWlyZSgnd2luc3RvbicpO1xuLy9yZXF1aXJlKCd3aW5zdG9uLWxvZ2dseS1idWxrJyk7XG4gXG4vLyB3aW5zdG9uLmFkZCh3aW5zdG9uLnRyYW5zcG9ydHMuTG9nZ2x5LCB7XG4vLyAgIGlucHV0VG9rZW46IFwiVE9LRU5cIixcbi8vICAgc3ViZG9tYWluOiBcIlNVQkRPTUFJTlwiLFxuLy8gICB0YWdzOiBbXCJtZXRlb3JcIiwgXCJ3aW5zdG9uXCJdLFxuLy8gICBqc29uOnRydWVcbi8vIH0pO1xuICBcbiAgXG5cblxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAvLyBjb2RlIHRvIHJ1biBvbiBzZXJ2ZXIgYXQgc3RhcnR1cFxufSk7XG5cbmlmKE1ldGVvci5pc1NlcnZlcil7XG4gICAgY29uc29sZS5sb2coXCJIZWxsbyBzZXJ2ZXJcIik7XG4gIFxuXHRcblx0Ly9cXC5tZXRlb3JcXGxvY2FsXFxidWlsZFxccHJvZ3JhbXNcXHNlcnZlclxuXG5cdE1ldGVvci5tZXRob2RzKHtcbiAgICBcblx0XHQnbG9nVG9GaWxlJzogZnVuY3Rpb24obWVzc2FnZSl7XG5cdFx0ICAgIFxuXHRcdCAgICB2YXIgbG9nNGpzID0gcmVxdWlyZSgnbG9nNGpzJyk7XG5cdFx0XHRsb2c0anMuY29uZmlndXJlKHtcblx0XHRcdCAgYXBwZW5kZXJzOiB7IGNoZWVzZTogeyB0eXBlOiAnZmlsZScsIGZpbGVuYW1lOiAnY2hlZXNlLmxvZycgfSB9LFxuXHRcdFx0ICBjYXRlZ29yaWVzOiB7IGRlZmF1bHQ6IHsgYXBwZW5kZXJzOiBbJ2NoZWVzZSddLCBsZXZlbDogJ2Vycm9yJyB9IH1cblx0XHRcdH0pO1xuXHRcdFx0IFxuXHRcdFx0dmFyIGxvZ2dlciA9IGxvZzRqcy5nZXRMb2dnZXIoJ2NoZWVzZScpO1xuXHRcdFx0XG5cdFx0XHRsb2dnZXIubGV2ZWwgPSAnZGVidWcnO1xuXHRcdFxuXHRcdFx0Ly92YXIgaW5mYTsvLyA9IFNlc3Npb24uZ2V0KCdsb2dnZXJJbmZvJyk7XG5cblx0XHRcdGxvZ2dlci5kZWJ1ZyhtZXNzYWdlKTtcblx0XHRcdFxuXHRcdFx0Ly8gdmFyIGxvZzRqcyA9IHJlcXVpcmUoJ2xvZzRqcycpO1xuXHRcdFx0Ly8gdmFyIGxvZ2dlciA9IGxvZzRqcy5nZXRMb2dnZXIoKTtcblx0XHRcdC8vIGxvZ2dlci5sZXZlbCA9ICdkZWJ1Zyc7XG5cdFx0XHQvLyBsb2dnZXIuZGVidWcobWVzc2FnZSk7XG4gICAgXHR9XG5cbn0pO1xuXG5cdFxuXG5cblx0Ly9sb2dnZXIuZGVidWcoXCJTb21lIGRlYnVnIG1lc3NhZ2VzXCIpO1xuICAgIC8vbG9nLmluZm8oXCJsb2dTdHJpbmdcIik7XG4gICAgQWNjb3VudHMub25DcmVhdGVVc2VyKGZ1bmN0aW9uKG9wdGlvbnMsIHVzZXIpIHtcbiAgICAvL3Bhc3MgdGhlIHN1cm5hbWUgaW4gdGhlIG9wdGlvbnNcbiAgICAgICAgY29uc29sZS5sb2cob3B0aW9ucy5wcm9maWxlKTtcbiAgICAgICAgLy9sb2cuaW5mbygnVXNlciB1cGRhdGVkIHdpdGggJywgb3B0aW9ucy5wcm9maWxlLCAnIGFjY2VwdGVkIGF0ICcsIG5ldyBEYXRlKCkudG9KU09OKCkpO1xuICAgICAgICB1c2VyLnByb2ZpbGUgPSBvcHRpb25zLnByb2ZpbGU7XG4gICAgICAgIHJldHVybiB1c2VyO1xuICAgIH0pO1xufVxuXG4iXX0=
